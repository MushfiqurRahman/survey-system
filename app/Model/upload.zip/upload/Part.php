<?php
App::uses('AppModel', 'Model');
/**
 * Part Model
 *
 * @property SurveyType $SurveyType
 * @property Task $Task
 */
class Part extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'title';

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'title' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'is_optional' => array(
			'boolean' => array(
				'rule' => array('boolean'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
        
        public $belongsTo = array(
            'FrontEndMenu' => array(
			'className' => 'FrontEndMenu',
			'foreignKey' => 'front_end_menu_id',
			'conditions' => '',
			'fields' => '',
			'order' => '',
                        'dependent' => true
		),
        );

	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * hasAndBelongsToMany associations
 *
 * @var array
 */
	public $hasAndBelongsToMany = array(
		'SurveyType' => array(
			'className' => 'SurveyType',
			'joinTable' => 'parts_survey_types',
			'foreignKey' => 'part_id',
			'associationForeignKey' => 'survey_type_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
			'deleteQuery' => '',
			'insertQuery' => ''
		),
		'Task' => array(
			'className' => 'Task',
			'joinTable' => 'parts_tasks',
			'foreignKey' => 'part_id',
			'associationForeignKey' => 'task_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
			'deleteQuery' => '',
			'insertQuery' => ''
		)
	);

}
